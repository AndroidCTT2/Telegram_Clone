package com.mobile.messageclone.Ulti;

public interface RecyclerViewClickInterface {
    void onItemClick(int position);
    void onLongItemClick (int position);
}
