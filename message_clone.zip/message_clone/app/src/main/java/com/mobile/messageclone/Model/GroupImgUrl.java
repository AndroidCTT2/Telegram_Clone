package com.mobile.messageclone.Model;

public class GroupImgUrl  {
    public String ImgUrl;

}
