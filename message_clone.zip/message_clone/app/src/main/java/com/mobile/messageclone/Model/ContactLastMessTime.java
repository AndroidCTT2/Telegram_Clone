package com.mobile.messageclone.Model;

import com.mobile.messageclone.Model.Contact;
import com.mobile.messageclone.Model.Message;

public class ContactLastMessTime {



    public Contact contact;
    public Message LastMess;
    public String profileImg;
    public String groupName;
    public int type;


    public ContactLastMessTime()
    {
        contact=new Contact();
        groupName=null;

    }

}
