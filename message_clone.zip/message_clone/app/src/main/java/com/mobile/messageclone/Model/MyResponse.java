package com.mobile.messageclone.Model;

public class MyResponse {
    public int success;
    public MyResponse(int response){
        this.success = response;
    }
}
