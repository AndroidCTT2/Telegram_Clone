package com.mobile.messageclone.Ulti;

public interface RecyclerCheckBoxClick {
    public void CheckBoxClick(int position,boolean check);
}
